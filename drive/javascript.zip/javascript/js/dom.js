let firstDiv = document.getElementById("main");
console.log(firstDiv);
let allPara = document.getElementsByTagName("p");
console.log(allPara);
