numArray = [1,123,12,11111,424334,12231,1,12,16,24,7,27,29,16];
function printNumArray(){
    let printDiv = document.getElementById("listArray");
    printDiv.innerHTML += "<ul>"; 
    for(i=0; i<numArray.length; i++){
        printDiv.innerHTML += `<li>${numArray[i]}</li>`;
    }
    printDiv.innerHTML += "</ul>";
}

printNumArray();


function printSum(){
    let printDiv = document.getElementById("sumOfArray");
    result = 0;
    for(i=0; i<numArray.length; i++){
        result += numArray[i];
    }
    printDiv.innerHTML += `<h1> The sum is: ${result} <h1>`;
}

printSum();


function wholeEq(){
    let printDiv = document.getElementById("wholeEq");
    result = 0;
    for(i=0; i<numArray.length; i++){
        result += numArray[i];
    }
    for(i=0; i<numArray.length; i++){
        if(i === numArray.length-1){
            printDiv.innerHTML += `${numArray[i]} = `
        }
        else {
            printDiv.innerHTML += `${numArray[i]} + `
        }         
    }
    printDiv.innerHTML += `${result}`;
}

wholeEq();