function recipe(){
let nameRecipe = prompt("Enter the name of the recipe");
let numberIngredients = parseInt(prompt("Enter the number of ingredients"));
if(isNaN(numberIngredients)){
    alert("Please enter valid number");
}
tempArray = [];
for(i=1; i<=numberIngredients; i++){
    tempArray.push(prompt(`Enter the name of ingredient number ${i}`));
}
let printDiv = document.getElementById("recipe");
printDiv.innerHTML += `<h1 align="center"> The name of your recipe is: ${nameRecipe} </h1>`
let printDiv2 = document.getElementById("ingredients");
printDiv2.innerHTML += "<ul>";
for(i=0; i<tempArray.length; i++){
    printDiv2.innerHTML += `<li> ${tempArray[i]} </li>`
}
}

recipe();