document.getElementById("myTitle").innerHTML = `This text is changed`;
let paragraphs = document.getElementsByTagName("p");
paragraphs[0].innerHTML = `And this text is changed too`;
paragraphs[1].innerHTML = `This is paragraph`;
let headerTemp = document.getElementsByTagName("h1");
headerTemp[1].innerHTML = `New text`;
let header3 = document.getElementsByTagName("h3");
header3[0].innerHTML = `CHANGES DONE`;
